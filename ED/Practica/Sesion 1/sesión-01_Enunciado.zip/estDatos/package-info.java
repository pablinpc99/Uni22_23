/**
 * Interfaces y clases de ejemplo para la asignatura de
 * Estructuras de Datos.
 *
 * @version 1.0
 */
package estDatos;
